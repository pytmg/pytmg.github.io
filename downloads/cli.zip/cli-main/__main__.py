import subprocess
subprocess.run(['python', 'example.py']) # Run example.py